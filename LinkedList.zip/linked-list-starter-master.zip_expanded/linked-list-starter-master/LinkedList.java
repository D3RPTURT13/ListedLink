/**
 * This class implements a singly linked list data structure.
 * 
 * @author Michael Ida
 *
 */


public class LinkedList {
	private Node first;
	private Node head;
	private Node tail;
	int data;
public static class listNode{
	public int data;
	private listNode next;
	public listNode(int data) {
		this.data = data;
		this.next = null;
	}
	}
	/*
	 * The constructor creates an empty list.
	 */
	public LinkedList() {
		head = null;
	}
	
	/*
	 * This method creates a new node and adds it to the head of the list.
	 */
	public void insertFirst(String data) {
		 if (head == null)
		    {
		        System.out.println("The given previous node cannot be null");
		        return;
		    }
		    Node new_node = new Node();
		    new_node.next = head.next;
		    head.next = head;
	}
	/*
	 * This method deletes the first node in the list.
	 */
	public void deleteFirst() {
		 if (head == null)
             return;
       else {
             if (head == tail) {
                   head = null;
                   tail = null;
             } else {
                   head = head.next;
             }
       }
	}
	
	/*
	 * This method should create a new node containing data and add it following the node 'after'.
	 * If after is null, then it should do nothing.
	 */
	public void insertAfter(listNode previous, Node after) {
		if (previous == null ) {
			System.out.println("the previous node is not null");
			return;
		}
		listNode newNode = new listNode(data);
		newNode.next = previous.next;
		previous.next = newNode;
	}
	
	/*
	 * This method should find the node containing the string data and return a pointer to that node.
	 * If not found, then it should return null.
	 */
	public Node findNode(int index, int data) {
		 Node current = head;
	        int count = 0; /* index of Node we are
	                          currently looking at */
	        while (current != null)
	        {
	            if (count == index) {
	                return current.data;
	            }
	            count++;
	            current = current.next;
	        }
	 
	        /* if we get to this line, the caller was asking
	        for a non-existent element so we assert fail */
	        assert(false);
	        return 0;
	}
	
	/*
	 * This method should delete the node trash.
	 * If trash is null, then it does nothing.
	 */
	public void deleteNode(listNode node) {
		node.val = node.next.val;
	    node.next = node.next.next;
	}
	
	/*
	 * This method should create a new node and insert it at the end of the list.
	 */
	
	public void insertLast(String data) {
		ListNode current=head;
        while(current.next!=null){
            current=current.next;
        }
        current.next=new ListNode(data);
        current=current.next;
        size--;
	    }
	
	
	/*
	 * This method deletes the last node in the list.
	 * If the list is empty, then it does nothing.
	 */
	public void deleteLast() {
		 Node temp= new Node();
		  Node trail = new Node();
		  
		  
		  temp= first;
		  while(temp.next!=null){
			  trail=temp;
			  temp=temp.next;
	}
	
	/*
	 * This method transverses the list and prints out the record in each node.
	 */
	public void traverseAndPrint() {
		Node pointer = head;
		while (pointer != null) {
			System.out.println(pointer.record);
			pointer = pointer.next;
		}
		System.out.println();
	}
	
}
